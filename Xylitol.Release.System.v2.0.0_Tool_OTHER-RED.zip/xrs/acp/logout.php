<?php

session_destroy();

?>
Logout success, you will be redirected on 1 sec
<script type="text/javascript">
<!--
var obj = 'window.location.replace("index.php");';
setTimeout(obj,1000);
// -->
</script>
