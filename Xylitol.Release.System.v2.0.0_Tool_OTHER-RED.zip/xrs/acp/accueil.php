<?php defined('CORE_ACP') or exit; ?>

<h1>:: Administration Control Panel ::</h1>
<hr />
<ul>
	<li><a href="acp.php?crk=addrelease">Add a &#1103;elease</a></li>
	<li><a href="acp.php?crk=modifrlz">Edit &#1103;eleases</a></li>
	<li><a href="acp.php?crk=delrelease">Delete &#1103;eleases</a></li>
	<li><a href="acp.php?crk=modifabout">Edit Team's About</a></li>
	--- Require database's password ---
	<li><a href="acp.php?crk=uninstall">Uninstall XRS</a></li>
	<li><a href="acp.php?crk=editconfig">Edit Configuration File</a></li>
</ul>
<p><b>XRS version:</b> 2.0.0</p>
<hr />
