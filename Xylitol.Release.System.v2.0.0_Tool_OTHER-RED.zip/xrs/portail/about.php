<?php

defined('CORE') or exit;

readfile('libs/about.txt');
